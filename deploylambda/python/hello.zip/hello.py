def lambda_handler(event, context):
    message = "Hello world"
    return {
        'message': message
    }
